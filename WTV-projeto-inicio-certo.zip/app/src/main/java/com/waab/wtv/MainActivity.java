package com.waab.wtv;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends Activity {
  private WebView web;
  @Override public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    web = new WebView(this);
    web.setBackgroundColor(0xFF080B18);
    web.getSettings().setJavaScriptEnabled(true);
    web.getSettings().setDomStorageEnabled(true);
    web.getSettings().setMediaPlaybackRequiresUserGesture(false);
    web.getSettings().setSupportMultipleWindows(false);
    web.addJavascriptInterface(new ExternalLinks(), "WTV");
    web.setWebChromeClient(new WebChromeClient());
    web.setWebViewClient(new WebViewClient());
    setContentView(web);
    web.loadUrl("file:///android_asset/index.html");
  }
  private class ExternalLinks {
    @JavascriptInterface public void openExternal(String value) {
      runOnUiThread(() -> {
        try {
          Uri uri = Uri.parse(value);
          if ("https".equalsIgnoreCase(uri.getScheme())) {
            startActivity(new Intent(Intent.ACTION_VIEW, uri));
          } else { Toast.makeText(MainActivity.this, "Link não permitido", Toast.LENGTH_SHORT).show(); }
        } catch (Exception e) { Toast.makeText(MainActivity.this, "Não foi possível abrir o link", Toast.LENGTH_SHORT).show(); }
      });
    }
  }
  @Override public boolean onKeyDown(int keyCode, KeyEvent event) {
    if (keyCode == KeyEvent.KEYCODE_BACK && web != null && web.canGoBack()) { web.goBack(); return true; }
    if (keyCode == KeyEvent.KEYCODE_BACK) { web.evaluateJavascript("document.getElementById('player').classList.contains('show') ? document.getElementById('back').click() : null", null); return true; }
    return super.onKeyDown(keyCode, event);
  }
  @Override protected void onDestroy() { if (web != null) web.destroy(); super.onDestroy(); }
}
